/* 
 * File:   Figure.cpp
 * Author: Rubén Ballester Bautista | Oriol Rabasseda Alcaide
 *
 * Created on 3 / març / 2016, 12:17
 */

#include "Figure.h"
#include <iostream>

using namespace std;

Figure::Figure() {
    //cout << "Sóc el constructor de Figure" << endl;
}

Figure::Figure(const Figure& orig) {
}

Figure::~Figure() {
}

