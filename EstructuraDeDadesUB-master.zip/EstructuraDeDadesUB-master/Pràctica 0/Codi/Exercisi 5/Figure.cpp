/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Figure.cpp
 * Author: rballeba50.alumnes
 * 
 * Created on 3 / març / 2016, 12:35
 */

#include "Figure.h"
#include <iostream>

using namespace std;

Figure::Figure() {
    //cout << "Sóc el constructor de Figure" << endl;
}

Figure::Figure(const Figure& orig) {
}

Figure::~Figure() {
}

